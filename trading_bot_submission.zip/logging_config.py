"""Logging configuration for the trading bot."""
import logging
import os
from logging.handlers import RotatingFileHandler

LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
_PKG = "bot"  # matches the package name used in __name__ across all modules
LOG_FILE = os.path.join(LOG_DIR, "trading_bot.log")

_FORMATTER = logging.Formatter(
    "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)


def setup_logging() -> None:
    """Configure file logging for the trading_bot logger. Call once at startup."""
    os.makedirs(LOG_DIR, exist_ok=True)

    logger = logging.getLogger(_PKG)
    if logger.handlers:
        return

    logger.setLevel(logging.DEBUG)

    file_handler = RotatingFileHandler(
        LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(_FORMATTER)
    logger.addHandler(file_handler)
