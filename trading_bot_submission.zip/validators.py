"""Input validation for order parameters."""
import re
from typing import Optional

VALID_SIDES = ("BUY", "SELL")
VALID_ORDER_TYPES = ("MARKET", "LIMIT")

# Futures pairs follow the pattern: base asset + quote asset (e.g. BTCUSDT, ETHBTC)
_SYMBOL_RE = re.compile(r"^[A-Z]{2,10}(USDT|BUSD|BTC|ETH|BNB)$")


def validate_symbol(symbol: str) -> str:
    value = symbol.strip().upper()
    if not value:
        raise ValueError("Symbol cannot be empty.")
    if not _SYMBOL_RE.match(value):
        raise ValueError(
            f"'{value}' does not look like a valid futures symbol (e.g. BTCUSDT, ETHUSDT)."
        )
    return value


def validate_side(side: str) -> str:
    value = side.strip().upper()
    if value not in VALID_SIDES:
        raise ValueError(f"Side must be BUY or SELL, got '{side}'.")
    return value


def validate_order_type(order_type: str) -> str:
    value = order_type.strip().upper()
    if value not in VALID_ORDER_TYPES:
        raise ValueError(
            f"Order type must be one of {', '.join(VALID_ORDER_TYPES)}, got '{order_type}'."
        )
    return value


def validate_quantity(quantity: float) -> float:
    if quantity <= 0:
        raise ValueError(f"Quantity must be greater than 0, got {quantity}.")
    return quantity


def validate_price(price: Optional[float], order_type: str) -> Optional[float]:
    if order_type == "LIMIT" and (price is None or price <= 0):
        raise ValueError("--price is required and must be a positive number for LIMIT orders.")
    return price
