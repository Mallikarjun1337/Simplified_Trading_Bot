"""CLI entry point — Binance Futures Testnet trading bot.

Usage:
  python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001
  python -m bot.cli --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 80000
  python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001 --dry-run
"""
import argparse
import logging
import os
import sys

from .client import BinanceClient
from .exceptions import BinanceAPIError, NetworkError
from .logging_config import setup_logging
from .orders import place_order

logger = logging.getLogger(__name__)

_COL_WIDTH = 12  # column width for aligned output


def _credentials() -> tuple[str, str]:
    api_key = os.getenv("BINANCE_API_KEY", "").strip()
    api_secret = os.getenv("BINANCE_API_SECRET", "").strip()
    if not api_key or not api_secret:
        _exit_error(
            "BINANCE_API_KEY and BINANCE_API_SECRET environment variables must be set.\n"
            "  Export them before running:\n"
            "    export BINANCE_API_KEY=your_key\n"
            "    export BINANCE_API_SECRET=your_secret",
            code=1,
        )
    return api_key, api_secret


def _exit_error(message: str, code: int = 1) -> None:
    logger.error(message)
    print(f"\n  [ERROR] {message}\n", file=sys.stderr)
    sys.exit(code)


def _divider() -> str:
    return "  " + "─" * 34


def _print_summary(symbol: str, side: str, order_type: str, quantity: float, price, dry_run: bool) -> None:
    print(f"\n  {'Order Request' if not dry_run else 'Dry Run — Order Preview'}")
    print(_divider())
    print(f"  {'Symbol':<{_COL_WIDTH}}: {symbol.upper()}")
    print(f"  {'Side':<{_COL_WIDTH}}: {side.upper()}")
    print(f"  {'Type':<{_COL_WIDTH}}: {order_type.upper()}")
    print(f"  {'Quantity':<{_COL_WIDTH}}: {quantity}")
    if price is not None:
        print(f"  {'Price':<{_COL_WIDTH}}: {price}")
    print(_divider())


def _print_response(response: dict) -> None:
    avg_price = response.get("avgPrice") or response.get("price") or "N/A"
    status = response.get("status", "N/A")
    executed = response.get("executedQty", "N/A")

    print(f"\n  Order Confirmed")
    print(_divider())
    print(f"  {'Order ID':<{_COL_WIDTH}}: {response.get('orderId')}")
    print(f"  {'Status':<{_COL_WIDTH}}: {status}")
    print(f"  {'Executed':<{_COL_WIDTH}}: {executed}")
    print(f"  {'Avg Price':<{_COL_WIDTH}}: {avg_price}")
    print(_divider())
    print(f"\n  [OK] Order placed successfully.\n")


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading-bot",
        description="Place orders on Binance Futures Testnet (USDT-M).",
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001\n"
            "  python -m bot.cli --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.001 --price 80000\n"
            "  python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.001 --dry-run"
        ),
    )
    parser.add_argument("--symbol", required=True, metavar="SYMBOL",
                        help="Trading pair (e.g. BTCUSDT)")
    parser.add_argument("--side", required=True, choices=["BUY", "SELL"],
                        type=str.upper, help="BUY or SELL")
    parser.add_argument("--type", required=True, dest="order_type",
                        choices=["MARKET", "LIMIT"], type=str.upper,
                        help="Order type")
    parser.add_argument("--quantity", required=True, type=float,
                        help="Order quantity")
    parser.add_argument("--price", type=float, default=None,
                        help="Limit price (required for LIMIT orders)")
    parser.add_argument("--dry-run", action="store_true",
                        help="Preview the order without submitting it")
    return parser


def _validate_args(args: argparse.Namespace) -> None:
    """Catch CLI mistakes that argparse cannot enforce."""
    if args.order_type == "LIMIT" and args.price is None:
        _exit_error("--price is required for LIMIT orders.", code=2)


def main() -> None:
    setup_logging()

    args = _build_parser().parse_args()
    _validate_args(args)
    _print_summary(args.symbol, args.side, args.order_type, args.quantity, args.price, args.dry_run)

    if args.dry_run:
        print("  Dry run complete. No order was submitted.\n")
        return

    api_key, api_secret = _credentials()
    client = BinanceClient(api_key=api_key, api_secret=api_secret)

    try:
        response = place_order(
            client=client,
            symbol=args.symbol,
            side=args.side,
            order_type=args.order_type,
            quantity=args.quantity,
            price=args.price,
        )
    except ValueError as exc:
        _exit_error(f"Validation failed — {exc}", code=2)
    except BinanceAPIError as exc:
        _exit_error(f"API error ({exc.code}) — {exc.message}", code=3)
    except NetworkError as exc:
        _exit_error(f"Network error — {exc}", code=4)

    _print_response(response)


if __name__ == "__main__":
    main()
