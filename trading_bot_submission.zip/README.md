# Binance Futures Testnet Trading Bot

A Python CLI application for placing MARKET and LIMIT orders on Binance Futures Testnet (USDT-M).
Built with `python-binance`, structured for readability, and designed with production practices in mind.

---

## Features

- Place MARKET and LIMIT orders (BUY / SELL)
- CLI input via `argparse` with validation
- `--dry-run` flag to preview orders without submitting
- Structured logging to file with timestamps (`logs/trading_bot.log`)
- Clean error handling: API errors, invalid input, network failures
- Modular codebase: client, orders, validators, logging, CLI layers separated

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── client.py          # python-binance wrapper
│   ├── orders.py          # order placement logic
│   ├── validators.py      # input validation
│   ├── logging_config.py  # logging setup
│   ├── exceptions.py      # custom exceptions
│   └── cli.py             # CLI entry point
├── logs/                  # auto-created on first run
├── requirements.txt
└── README.md
```

---

## Setup

**1. Install dependencies**
```bash
pip install -r requirements.txt
```

**2. Set API credentials**
```bash
# Linux / macOS
export BINANCE_API_KEY="your_api_key"
export BINANCE_API_SECRET="your_api_secret"

# Windows (PowerShell)
$env:BINANCE_API_KEY="your_api_key"
$env:BINANCE_API_SECRET="your_api_secret"
```

> Get testnet credentials at [testnet.binancefuture.com](https://testnet.binancefuture.com) — log in with GitHub and generate an API key.

---

## Usage

Run all commands from inside the `trading_bot/` directory.

```bash
# MARKET order
python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01

# LIMIT order
python -m bot.cli --symbol BTCUSDT --side SELL --type LIMIT --quantity 0.01 --price 80000

# Preview without submitting
python -m bot.cli --symbol BTCUSDT --side BUY --type MARKET --quantity 0.01 --dry-run

# Help
python -m bot.cli --help
```

---

## Sample Output

```
  Order Request
  ──────────────────────────────────────
  Symbol      : BTCUSDT
  Side        : BUY
  Type        : MARKET
  Quantity    : 0.01
  ──────────────────────────────────────

  Order Confirmed
  ──────────────────────────────────────
  Order ID    : 12995468953
  Status      : NEW
  Executed    : 0.000
  Avg Price   : 0.00
  ──────────────────────────────────────

  [OK] Order placed successfully.
```

Log entry written to `logs/trading_bot.log`:
```
2026-03-26 17:46:17 | INFO  | bot.orders | Placing BUY MARKET order | symbol=BTCUSDT qty=0.01
2026-03-26 17:46:18 | INFO  | bot.orders | Order accepted | id=12995468953 status=NEW executedQty=0.000 avgPrice=0.00
```

---

## Assumptions

- Targets USDT-M Futures only (not COIN-M)
- Credentials are provided via environment variables, not hardcoded
- Minimum order notional is $100 (testnet rule) — use quantity `0.01` for BTCUSDT
- LIMIT orders use `timeInForce=GTC` by default
- Python 3.10+ required for union type hints (`X | Y`)
