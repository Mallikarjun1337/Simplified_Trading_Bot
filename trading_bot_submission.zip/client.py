"""Binance Futures Testnet client wrapper using python-binance."""
import logging
from typing import Any

from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceRequestException

from .exceptions import BinanceAPIError, NetworkError

logger = logging.getLogger(__name__)


class BinanceClient:
    def __init__(self, api_key: str, api_secret: str) -> None:
        self._client = Client(
            api_key=api_key,
            api_secret=api_secret,
            tld="com",
            testnet=True,
        )

    def new_order(self, **kwargs: Any) -> dict[str, Any]:
        logger.debug("Placing futures order: %s", kwargs)
        try:
            response = self._client.futures_create_order(**kwargs)
        except BinanceAPIException as exc:
            logger.error("Binance API error: code=%s msg=%s", exc.code, exc.message)
            raise BinanceAPIError(exc.code, exc.message) from exc
        except BinanceRequestException as exc:
            raise NetworkError(str(exc)) from exc
        logger.debug("Order response: %s", response)
        return response
