"""Custom exceptions for the trading bot."""


class BinanceAPIError(Exception):
    """Raised when the Binance API returns an error response."""

    def __init__(self, code: int | str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"[{code}] {message}")


class NetworkError(Exception):
    """Raised on connection or timeout failures."""
